let count = 0
function addNum(id)
{
    count++;
    document.getElementById(id).innerText = count;
}